﻿// Learn more about F# at http://fsharp.org

open System

[<EntryPoint>]
let main argv =
    printfn "Hello World from my F#! program!"
    printfn "The args are: %A" argv
    0 // return an integer exit code
